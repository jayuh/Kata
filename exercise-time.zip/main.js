new Vue({
  el: '#app',
  data: {
    switch: false,
    status: 'none',
    settingSportTime: 2,
    settingRestTime: 9,
    settingTimes: 15,
    sportTime: 0,
    restTime: 0,
    times: 0,
    progress: '0%'
  },
  computed: {
    btnText: function () {
      return this.switch ? 'Stop!' : 'Start!'
    }
  },
  created: function () {
  },
  methods: {
    handleSetting: function () {
      this.status = 'setting'
      this.switch = false
    },
    reset: function () {
      this.switch = false
      this.status = 'none'
      this.sportTime = 0
      this.restTime = this.settingRestTime
      this.times = 0
    },
    go: function () {
      this.switch = !this.switch;
      if (this.status === 'none' || this.status === 'setting') {
        this.status = 'sport'
        this.restTime = this.settingRestTime
      }
      if (this.switch) {
        this.status === 'sport' && this.sportCountTime()
        this.status === 'rest' && this.restCountTime()
      }
    },
    sportCountTime: function () {
      if (!this.switch) return
      setTimeout(() => {
        this.sportTime++
        if (this.sportTime <= this.settingSportTime) {
          this.sportCountTime()
          this.progress = this.sportTime / this.settingSportTime * 100 + '%'
        } else {
          this.restCountTime()
          this.sportTime = 0
          this.status = 'rest'
        }
      }, 1000)
    },
    restCountTime: function () {
      if (!this.switch) return
      setTimeout(() => {
        this.restTime--
        if (this.restTime >= 0) {
          this.restCountTime()
          this.progress = this.restTime / this.settingRestTime * 100 + '%'
        } else {
          this.sportCountTime()
          this.restTime = this.settingRestTime
          this.status = 'sport'
          this.times++
          console.log(`${this.times}, ${this.settingTimes}`)
          if (this.times === this.settingTimes - 0) {
            this.status = 'finish'
            this.switch = false
          }
        }
      }, 1000)
    }
  }
})
